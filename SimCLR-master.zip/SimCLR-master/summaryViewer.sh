tensorboard --logdir=./runs/May18_01-03-54_userme/ --port=8009 --host=localhost
